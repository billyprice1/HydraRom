#!/system/bin/sh

/magisk/xposed/unmount.sh &