#!/system/bin/sh

LOGFILE=/cache/magisk.log

log_print() {
  echo "Xposed: $1"
  echo "Xposed: $1" >> $LOGFILE
  log -p i -t Xposed "$1"
}

if [ `cat /proc/mounts | grep /su >/dev/null 2>&1; echo $?` -eq 0 ]; then
  if [ -d "/su/bin" ]; then
    if [ `ps | grep -v "launch_daemonsu.sh" | grep "daemonsu" >/dev/null 2>&1; echo $?` -eq 0 ]; then
      # Cannot unmount app_process if running SuperSU
      log_print "SuperSU detected! Do not unmount!"
      exit
    fi
  fi
fi

sleep 20;
log_print "Lazy unmount app_process"

umount -l /system/bin/app_process32
if [ -f "/system/bin/app_process64" ]; then
  umount -l /system/bin/app_process64
fi